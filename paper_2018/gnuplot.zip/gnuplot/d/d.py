import csv
import os
cwd = os.getcwd()
f = []
filelist = []
for (path, dir, files) in os.walk(cwd+'/mining_result'):
	for filename in files:

		if filename[-3:] == 'txt':
			filelist.append(filename)
filelist.sort()
for filename in filelist:
	file_tmp = open(cwd +"/mining_result/"+ filename, 'r')
	f.append(file_tmp)

count = 1
filelength = len(f)
print(f)
for line in f[0].readlines():
	# print(line)
	with open("result_mining.csv", "a") as csvfile:

		csvfile.writelines(str(count) + ", "+ str(round(float(line.split(', ')[4]), 4)))
		for i in range(1, filelength):
			line_tmp = f[i].readline()
			#print(line_tmp)
			csvfile.writelines(", " + str(round(float(line_tmp.split(', ')[4]), 4)))
		csvfile.writelines("\n")
	count = count + 1

